// ==========================================
// File Name : pointer_basics.c
// Author    : Ashwin M V
// Description : This program demonstrates
//               basic pointer usage in C
// ==========================================

#include <stdio.h>

int main() {

    // creating integer variable
    int port = 80;

    // creating pointer to port
    int *ptr = &port;

    // printing value using variable
    printf("Port value (using variable): %d\n", port);

    // printing value using pointer
    printf("Port value (using pointer): %d\n", *ptr);

    // changing value using pointer
    *ptr = 443;

    // printing updated value
    printf("New port value (after pointer update): %d\n", port);

    return 0;
}