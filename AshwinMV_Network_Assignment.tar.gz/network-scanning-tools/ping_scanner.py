# ==========================================
# File Name : ping_scanner.py
# Author    : Ashwin M V
# Description : This program performs ping scanning
#               for single, multiple hosts and even
#               network ranges. It also supports CSV
#               export, logging and threading.
# ==========================================

import subprocess
import platform
import re
import sys
import csv
import ipaddress
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor


# FUNCTION: get_ping_param
# this function checks the operating system and returns
# the correct ping parameter (-n for windows, -c for linux/mac)

def get_ping_param():
    return "-n" if platform.system().lower() == "windows" else "-c"


# FUNCTION: extract_avg_time
# this function tries to extract average response time
# from the ping output using regex (works for both OS types)

def extract_avg_time(output):

    # windows output format
    windows_match = re.search(r"Average = (\d+)ms", output)
    if windows_match:
        return windows_match.group(1) + " ms"

    # linux/mac output format
    linux_match = re.search(r"= [\d\.]+/([\d\.]+)/", output)
    if linux_match:
        return linux_match.group(1) + " ms"

    # if nothing matches
    return "N/A"


# FUNCTION: ping_host
# this function sends a ping request to a given host
# and returns host status and average response time

def ping_host(host):

    param = get_ping_param()

    try:
        result = subprocess.run(
            ["ping", param, "4", host],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10
        )

        output = result.stdout

        # checking whether host responded or not
        if result.returncode == 0:
            status = "Reachable"
        else:
            status = "Not Reachable"

        avg_time = extract_avg_time(output)

        return (host, status, avg_time)

    except subprocess.TimeoutExpired:
        return (host, "Timeout", "N/A")

    except Exception as e:
        return (host, "Error", str(e))


# FUNCTION: expand_hosts
# BONUS: this function allows user to enter CIDR ranges
# like 192.168.1.0/24 and expands it into individual IPs

def expand_hosts(input_hosts):

    hosts = []

    for item in input_hosts:
        item = item.strip()

        # checking if input is a network range
        if "/" in item:
            try:
                network = ipaddress.ip_network(item, strict=False)

                # adding all usable hosts
                for ip in network.hosts():
                    hosts.append(str(ip))

            except:
                print(f"Invalid network: {item}")
        else:
            hosts.append(item)

    return hosts


# FUNCTION: save_to_csv
# BONUS: saves scan results into a CSV file for later use

def save_to_csv(results):

    filename = "ping_results.csv"

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        # writing header
        writer.writerow(["Host", "Status", "Avg Time"])

        for row in results:
            writer.writerow(row)

    print(f"\n[+] Results saved to {filename}")


# FUNCTION: log_results
# BONUS: appends scan results into a log file with timestamp

def log_results(results):

    with open("ping_log.txt", "a") as log:
        log.write("\n--- Scan at " + str(datetime.now()) + " ---\n")

        for r in results:
            log.write(f"{r[0]} | {r[1]} | {r[2]}\n")


# FUNCTION: scan_hosts
# BONUS: uses multithreading so multiple hosts can be scanned faster

def scan_hosts(hosts):

    results = []

    print("\n=== Ping Results ===")
    print("{:<20} {:<15} {:<15}".format("Host", "Status", "Avg Time"))
    print("-" * 50)

    # using thread pool for faster scanning
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_results = executor.map(ping_host, hosts)

        for res in future_results:
            results.append(res)

            print("{:<20} {:<15} {:<15}".format(res[0], res[1], res[2]))

    return results


# MAIN PROGRAM

if __name__ == "__main__":

    print("=== Advanced Ping Scanner ===")

    try:
        # asking user whether to scan multiple hosts or not
        choice = input("Scan multiple hosts or network? (y/n): ").lower()

        if choice == "y":
            host_input = input("Enter hosts or network (comma separated): ")
            raw_hosts = host_input.split(",")
        else:
            raw_hosts = [input("Enter hostname or IP: ")]

        # expanding network ranges if given
        hosts = expand_hosts(raw_hosts)

        # performing scan
        results = scan_hosts(hosts)

        # BONUS: optional CSV export
        save_choice = input("\nSave results to CSV? (y/n): ").lower()
        if save_choice == "y":
            save_to_csv(results)

        # BONUS: logging results
        log_results(results)

    except KeyboardInterrupt:
        print("\nScan interrupted by user")
        sys.exit()

    except Exception as e:
        print("Error:", e)