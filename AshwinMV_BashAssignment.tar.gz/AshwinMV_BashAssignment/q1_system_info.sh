#!/bin/bash

# q1_system_info.sh
# Author : Ashwin M V

# This script shows basic system information
# I am storing command outputs in variables first so it is easier to print neatly

# get current username
USERNAME=$(whoami) 

# get system hostname
HOSTNAME=$(hostname)

# get current date and time
CURRENT_TIME=$(date "+%Y-%m-%d %H:%M:%S")

# get operating system name
OS_NAME=$(uname -s) 

# get present working directory
CURRENT_DIR=$(pwd)

# get home directory from HOME variable
HOME_DIR=$HOME 

# count number of users currently logged in
USERS_ONLINE=$(who | wc -l)

# get system uptime in readable format
SYSTEM_UPTIME=$(uptime -p)

# BONUS: ANSI color codes
GREEN="\e[32m"
BLUE="\e[34m"
YELLOW="\e[33m"
RESET="\e[0m"

# BONUS: get disk usage of root directory
DISK_USAGE=$(df -h / | awk 'NR==2 {print $3 " used out of " $2}')

# BONUS: get memory usage
MEMORY_USAGE=$(free -h | awk 'NR==2 {print $3 " used out of " $2}')

# Display information using echo and colors

echo -e "${BLUE}====================================${RESET}"
echo -e "${GREEN}        SYSTEM INFORMATION          ${RESET}"
echo -e "${BLUE}====================================${RESET}"

echo -e "${YELLOW}Username        :${RESET} $USERNAME"
echo -e "${YELLOW}Hostname        :${RESET} $HOSTNAME"
echo -e "${YELLOW}Date & Time     :${RESET} $CURRENT_TIME"
echo -e "${YELLOW}OS Name         :${RESET} $OS_NAME"
echo -e "${YELLOW}Current Dir     :${RESET} $CURRENT_DIR"
echo -e "${YELLOW}Home Dir        :${RESET} $HOME_DIR"
echo -e "${YELLOW}Users Online    :${RESET} $USERS_ONLINE"
echo -e "${YELLOW}System Uptime   :${RESET} $SYSTEM_UPTIME"

# BONUS output
echo -e "${YELLOW}Disk Usage      :${RESET} $DISK_USAGE"
echo -e "${YELLOW}Memory Usage    :${RESET} $MEMORY_USAGE"

echo -e "${BLUE}====================================${RESET}"