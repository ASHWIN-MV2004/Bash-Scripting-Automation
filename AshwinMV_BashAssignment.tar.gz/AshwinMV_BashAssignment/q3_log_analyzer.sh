#!/bin/bash

# q3_log_analyzer.sh
# Author : Ashwin M V

# This script analyzes a log file given as argument.
# It extracts IP addresses, status codes, and other useful information.

# check if filename is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 logfile"
    exit 1
fi

log_file=$1

# check if file exists
if [ ! -f "$log_file" ]; then
    echo "Log file does not exist."
    exit 1
fi

# check if file is empty
if [ ! -s "$log_file" ]; then
    echo "Log file is empty."
    exit 1
fi

echo "========= LOG ANALYSIS ========="

# count total entries using wc -l (as per assignment hint)
entry_count=$(wc -l < "$log_file")
echo "Total entries: $entry_count"

echo ""
echo "Unique IP addresses:"
# extract first column (IP address), sort and remove duplicates
awk '{print $1}' "$log_file" | sort | uniq

echo ""
echo "Status code summary:"
# extract last column (status code), count occurrences
awk '{print $NF}' "$log_file" | sort | uniq -c

echo ""
echo "Top 3 IP addresses:"
# count requests per IP and show top 3
awk '{print $1}' "$log_file" | sort | uniq -c | sort -nr | head -3


# BONUS: Date range analysis
echo ""
echo "========= DATE RANGE ANALYSIS ========="

# ask user to enter start and end date
read -p "Enter start date (DD/Mon/YYYY): " start_date
read -p "Enter end date (DD/Mon/YYYY): " end_date

echo ""
echo "Entries between $start_date and $end_date:"

# filter log entries between dates
awk -v start="$start_date" -v end="$end_date" '
{
    # extract date part from log entry
    match($0, /\[([0-9]{2}\/[A-Za-z]{3}\/[0-9]{4})/, arr)
    log_date = arr[1]

    # compare date range
    if (log_date >= start && log_date <= end)
        print
}
' "$log_file"

# count number of entries in that date range
range_count=$(awk -v start="$start_date" -v end="$end_date" '
{
    match($0, /\[([0-9]{2}\/[A-Za-z]{3}\/[0-9]{4})/, arr)
    log_date = arr[1]
    if (log_date >= start && log_date <= end)
        count++
}
END {print count+0}
' "$log_file")

echo ""
echo "Total entries in date range: $range_count"


# BONUS: detect security threats (multiple 403 errors from same IP)
echo ""
echo "========= SECURITY THREAT ANALYSIS ========="
echo "Suspicious IPs (multiple 403 errors):"

awk '$NF==403 {print $1}' "$log_file" | sort | uniq -c | awk '$1>1'


# BONUS: generate CSV report
echo ""
echo "========= GENERATING CSV REPORT ========="

# create CSV file with header
echo "IP,Request_Count" > log_report.csv

# write IP and request count to CSV
awk '{print $1}' "$log_file" | sort | uniq -c | awk '{print $2 "," $1}' >> log_report.csv

echo "CSV report saved as log_report.csv"