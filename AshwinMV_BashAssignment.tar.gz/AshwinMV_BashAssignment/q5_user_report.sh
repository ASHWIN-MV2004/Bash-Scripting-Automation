#!/bin/bash

# q5_user_report.sh
# Author : Ashwin M V

# This script generates a detailed user report using /etc/passwd, /etc/group and lastlog

echo "===================================="
echo "         USER REPORT SCRIPT         "
echo "===================================="

echo ""
echo "=== USER STATISTICS ==="

# count total users from /etc/passwd file
total_users=$(wc -l < /etc/passwd)

# count system users with UID less than 1000
system_users=$(awk -F: '$3 < 1000 {count++} END {print count+0}' /etc/passwd)

# count regular users with UID greater than or equal to 1000
regular_users=$(awk -F: '$3 >= 1000 {count++} END {print count+0}' /etc/passwd)

# count currently logged in users using who command
logged_users=$(who | awk '{print $1}' | sort -u | wc -l)

# display user statistics
echo "Total Users                : $total_users"
echo "System Users (UID < 1000) : $system_users"
echo "Regular Users (UID >=1000): $regular_users"
echo "Currently Logged In       : $logged_users"


# USER DETAILS TABLE
echo ""
echo "=== REGULAR USER DETAILS ==="

# print table header using printf for proper formatting
printf "%-15s %-6s %-20s %-15s %-25s\n" "Username" "UID" "Home Directory" "Shell" "Last Login"
printf "%-15s %-6s %-20s %-15s %-25s\n" "--------" "---" "--------------" "-----" "----------"

# read /etc/passwd and display user details
# also get last login using lastlog command
awk -F: '$3 >= 1000 {
    cmd = "lastlog -u " $1
    cmd | getline header
    cmd | getline lastlogin
    close(cmd)

    if (lastlogin ~ /Never logged in/)
        login="Never logged in"
    else
        login=lastlogin

    printf "%-15s %-6s %-20s %-15s %-25s\n", $1, $3, $6, $7, login
}' /etc/passwd


# GROUP INFORMATION
echo ""
echo "=== GROUP INFORMATION ==="

# print group table header
printf "%-20s %-10s\n" "Group Name" "Members"
printf "%-20s %-10s\n" "----------" "-------"

# read /etc/group and count number of members in each group
awk -F: '{
    if ($4=="")
        count=0
    else
        count=split($4, arr, ",")

    printf "%-20s %-10d\n", $1, count
}' /etc/group


# SECURITY CHECKS
echo ""
echo "=== SECURITY CHECKS ==="

# find users with root privileges (UID 0)
echo ""
echo "Users with root privileges (UID 0):"
awk -F: '$3==0 {print "- " $1}' /etc/passwd


# find users without passwords
# BONUS: password security check using /etc/shadow
echo ""
echo "Users without passwords:"

# check if script is run with sudo
if [ "$EUID" -ne 0 ]; then
    echo "Run script with sudo to check password security"
else

    no_pass=$(awk -F: '($2=="!" || $2=="") {print $1}' /etc/shadow)

    if [ -z "$no_pass" ]; then
        echo "All users have passwords set"
    else
        echo "$no_pass"
    fi

fi


# find inactive users using lastlog
echo ""
echo "Inactive users (never logged in):"
lastlog | grep "Never logged in"


# BONUS: password expiry information
echo ""
echo "=== PASSWORD EXPIRY INFO (BONUS) ==="

# get password expiry info using chage command
awk -F: '$3>=1000 {print $1}' /etc/passwd | while read user
do
    expiry=$(chage -l "$user" 2>/dev/null | grep "Password expires" | cut -d: -f2)
    echo "$user -> Expires:$expiry"
done


# BONUS: SAVE REPORT TO HTML FILE
html_file="user_report.html"

# create HTML report
echo "<html><body>" > $html_file
echo "<h2>User Report</h2>" >> $html_file

echo "<h3>User Statistics</h3>" >> $html_file
echo "<p>Total Users: $total_users</p>" >> $html_file
echo "<p>System Users: $system_users</p>" >> $html_file
echo "<p>Regular Users: $regular_users</p>" >> $html_file

echo "<h3>Root Users</h3><pre>" >> $html_file
awk -F: '$3==0 {print $1}' /etc/passwd >> $html_file
echo "</pre>" >> $html_file

echo "</body></html>" >> $html_file

echo ""
echo "[*] HTML report saved as $html_file"


# BONUS: GENERATE GRAPH DATA FILE (CSV format)
echo "Category,Count" > user_graph.csv
echo "Total,$total_users" >> user_graph.csv
echo "System,$system_users" >> user_graph.csv
echo "Regular,$regular_users" >> user_graph.csv

echo "[*] Graph data saved as user_graph.csv"


# BONUS: EMAIL REPORT OPTION

# check if mail command exists, if not install mailutils
if ! command -v mail >/dev/null 2>&1; then

    echo "[*] Mail utility not found."
    echo "[*] Installing mailutils..."

    sudo apt update >/dev/null 2>&1
    sudo apt install -y mailutils >/dev/null 2>&1

    echo "[*] Mailutils installed successfully."

fi

# ask user for email address
read -p "Enter email to send report (or press Enter to skip): " email

# send email if entered
if [ ! -z "$email" ]; then

    mail -s "User Report" "$email" < "$html_file"

    echo "[*] Email sent to $email"

fi


echo ""
echo "Report generation completed."
echo "===================================="