// ==========================================
// File Name : buffer_test.c
// Author    : Ashwin M V
// Description : This program demonstrates
//               buffer overflow vulnerability
// ==========================================

#include <stdio.h>
#include <string.h>

int main() {

    // buffer of size 16
    char buffer[16];

    // user input
    char input[100];

    printf("Enter some text: ");
    scanf("%s", input);

    // unsafe copy (no bounds checking)
    strcpy(buffer, input);

    // printing stored value
    printf("Buffer contains: %s\n", buffer);

    return 0;
}


/*
==========================================
ANSWERS TO QUESTIONS
==========================================

1. What happens with long input?

If the user enters input longer than 16 characters,
it overflows the buffer and overwrites adjacent memory.
This may cause:
- Program crash
- Unexpected behavior
- Memory corruption

------------------------------------------

2. Why is this dangerous?

Buffer overflow is dangerous because:
- It can overwrite critical memory
- Attackers can execute malicious code
- It is one of the most common security vulnerabilities

------------------------------------------

3. How would you fix it?

Use safer alternatives such as:
- strncpy() instead of strcpy()
- fgets() for input
- Limit input size

Example fix:
strncpy(buffer, input, sizeof(buffer)-1);

*/