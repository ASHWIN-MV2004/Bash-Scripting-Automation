# ==========================================
# File Name : password_checker.py
# Author    : Ashwin M V
# Description : This program checks the strength
#               of a password based on different
#               conditions and gives suggestions
# ==========================================

import re


# FUNCTION: check_password_strength
# this function checks different conditions and gives a score

def check_password_strength(password):

    score = 0
    suggestions = []

    # check length
    if len(password) >= 8:
        score += 1
    else:
        suggestions.append("Password should be at least 8 characters long")

    # check uppercase letters
    if re.search(r"[A-Z]", password):
        score += 1
    else:
        suggestions.append("Add at least one uppercase letter")

    # check lowercase letters
    if re.search(r"[a-z]", password):
        score += 1
    else:
        suggestions.append("Add at least one lowercase letter")

    # check digits
    if re.search(r"[0-9]", password):
        score += 1
    else:
        suggestions.append("Include at least one number")

    # check special characters
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    else:
        suggestions.append("Include at least one special character")

    return score, suggestions


# FUNCTION: get_strength_level
# this function converts score into strength level

def get_strength_level(score):

    if score == 5:
        return "Strong"
    elif score >= 3:
        return "Medium"
    else:
        return "Weak"


# MAIN PROGRAM

if __name__ == "__main__":

    print("=== Password Strength Checker ===")

    # taking input from user
    password = input("Enter password: ")

    score, suggestions = check_password_strength(password)

    strength = get_strength_level(score)

    print("\nPassword Strength:", strength)

    # show suggestions if not strong
    if strength != "Strong":
        print("\nSuggestions to improve password:")
        for s in suggestions:
            print("- " + s)