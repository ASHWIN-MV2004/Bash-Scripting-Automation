==================================================
NETWORK SCANNING TOOLS - ASSIGNMENT
==================================================

Name       : Ashwin M V
Course     : Cybersecurity / Network Security
Assignment : Network Scanning Tools using Python
Date       : March 25th, 2026

==================================================
1. OVERVIEW
==================================================

This project includes three network scanning tools developed using Python:

1. Ping Scanner
2. ARP Scanner
3. Nmap Scanner

In addition to these, a unified tool (network_scanner.py) is created as a bonus feature to combine all scanners into a single menu-driven program.

All scripts are mainly tested on Linux (Kali/Ubuntu) but are designed to work on other operating systems as well.

--------------------------------------------------

==================================================
2. REQUIREMENTS
==================================================

The following tools are required to run this project:

1. Python 3.6 or higher
   Check using:
   python3 --version

2. Nmap
   Install using:
   sudo apt update
   sudo apt install nmap

3. Built-in tools (already available):
   - ping
   - arp

--------------------------------------------------

==================================================
3. PROJECT FILES
==================================================

ping_scanner.py        - Performs ping scanning
arp_scanner.py         - Displays ARP table mappings
nmap_scanner.py        - Performs Nmap scans
network_scanner.py     - Unified scanner (Bonus)
README.txt             - Documentation
screenshots/           - Output screenshots

--------------------------------------------------

==================================================
4. HOW TO RUN THE PROGRAMS
==================================================

Open terminal in the project folder and run:

------------------------------------------
1. Ping Scanner
------------------------------------------
python3 ping_scanner.py

Features:
- Single and multiple host scanning
- Network range scanning (CIDR)
- Average response time extraction
- CSV export (bonus)
- Logging with timestamps (bonus)
- Multi-threaded scanning (bonus)

------------------------------------------
2. ARP Scanner
------------------------------------------
python3 arp_scanner.py

Features:
- Retrieves ARP table
- Extracts IP and MAC addresses
- Displays formatted output
- Saves results to text file
- CSV export (bonus)
- Logging (bonus)

------------------------------------------
3. Nmap Scanner
------------------------------------------
python3 nmap_scanner.py

Features:
- Host discovery scan (-sn)
- Port scan
- Custom port scan
- Service version detection (-sV)
- OS detection (-O)
- Save results to file
- CSV export (bonus)
- Logging (bonus)

------------------------------------------
4. Unified Scanner (BONUS)
------------------------------------------
python3 network_scanner.py

Menu Options:
1. Ping Scanner
2. ARP Scanner
3. Nmap Scanner
4. Exit

--------------------------------------------------

==================================================
5. SAMPLE TEST CASES
==================================================

Ping Scanner:
Input:
y
google.com, 127.0.0.1

Expected Output:
Shows reachable hosts and response time


ARP Scanner:
Command:
python3 arp_scanner.py

Expected Output:
List of IP and MAC addresses


Nmap Scanner:
Input:
127.0.0.1
2

Expected Output:
Displays port scan results


Unified Tool:
Select any option (1–3) from menu

--------------------------------------------------

==================================================
6. OUTPUT FILES GENERATED
==================================================

Ping Scanner:
- ping_results.csv
- ping_log.txt

ARP Scanner:
- arp_results.txt
- arp_results.csv
- arp_log.txt

Nmap Scanner:
- nmap_results.txt
- nmap_results.csv
- nmap_log.txt

--------------------------------------------------

==================================================
7. BONUS FEATURES IMPLEMENTED
==================================================

✔ Unified scanner (network_scanner.py)
✔ CSV export in all scanners
✔ Logging with timestamps
✔ Network range scanning (CIDR)
✔ Multi-threaded ping scanning

--------------------------------------------------

==================================================
8. SCREENSHOTS
==================================================

Screenshots are included in the "screenshots" folder:

- ping_output.png
- arp_output.png
- nmap_output.png
- unified_tool.png

--------------------------------------------------

==================================================
9. CHALLENGES FACED
==================================================

1. Understanding how to parse command output using regular expressions
2. Making scripts work across different operating systems
3. Extracting accurate response time from ping output
4. Handling subprocess errors and timeouts properly
5. Formatting output in a clean and readable way

All these issues were resolved through testing and debugging.

--------------------------------------------------

==================================================
10. CONCLUSION
==================================================

This assignment helped in understanding how real network scanning tools work and how system commands can be integrated with Python using the subprocess module.

==================================================