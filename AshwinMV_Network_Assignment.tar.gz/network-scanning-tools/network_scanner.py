# ==========================================
# File Name : network_scanner.py
# Author    : Ashwin M V
# Description : This is a unified network tool
#               which combines ping, ARP and
#               Nmap scanners into one menu-driven program.
# ==========================================

import subprocess
import sys


# FUNCTION: run_ping_scanner
# runs the ping scanner script

def run_ping_scanner():
    try:
        print("\nRunning Ping Scanner...\n")
        subprocess.run(["python3", "ping_scanner.py"])
    except Exception as e:
        print("Error running ping scanner:", e)


# FUNCTION: run_arp_scanner
# runs the arp scanner script

def run_arp_scanner():
    try:
        print("\nRunning ARP Scanner...\n")
        subprocess.run(["python3", "arp_scanner.py"])
    except Exception as e:
        print("Error running arp scanner:", e)


# FUNCTION: run_nmap_scanner
# runs the nmap scanner script

def run_nmap_scanner():
    try:
        print("\nRunning Nmap Scanner...\n")
        subprocess.run(["python3", "nmap_scanner.py"])
    except Exception as e:
        print("Error running nmap scanner:", e)


# FUNCTION: show_menu
# displays menu options

def show_menu():

    print("\n====== NETWORK SCANNER TOOL ======")
    print("1. Ping Scanner")
    print("2. ARP Scanner")
    print("3. Nmap Scanner")
    print("4. Exit")


# MAIN PROGRAM

if __name__ == "__main__":

    while True:

        try:
            show_menu()

            choice = input("Enter your choice: ")

            if choice == "1":
                run_ping_scanner()

            elif choice == "2":
                run_arp_scanner()

            elif choice == "3":
                run_nmap_scanner()

            elif choice == "4":
                print("Exiting program...")
                sys.exit()

            else:
                print("Invalid choice. Please try again.")

        except KeyboardInterrupt:
            print("\nProgram interrupted by user")
            sys.exit()

        except Exception as e:
            print("Error:", e)