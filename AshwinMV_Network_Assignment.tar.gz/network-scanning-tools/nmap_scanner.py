# ==========================================
# File Name : nmap_scanner.py
# Author    : Ashwin M V
# Description : This program runs different types of
#               Nmap scans based on user choice.
#               It also supports saving output,
#               CSV export and logging.
# ==========================================

import subprocess
import sys
import csv
from datetime import datetime


# FUNCTION: check_nmap_installed
# this function checks whether nmap is available in the system

def check_nmap_installed():
    try:
        subprocess.run(
            ["nmap", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5
        )
        return True
    except:
        return False


# FUNCTION: run_nmap_scan
# this function builds the nmap command based on user input
# and executes it using subprocess

def run_nmap_scan(target, choice):

    try:
        if choice == "1":
            cmd = ["nmap", "-sn", target]

        elif choice == "2":
            cmd = ["nmap", target]

        elif choice == "3":
            # asking user for custom port range
            ports = input("Enter port range (e.g., 1-100): ")
            cmd = ["nmap", "-p", ports, target]

        elif choice == "4":
            cmd = ["nmap", "-sV", target]

        elif choice == "5":
            cmd = ["nmap", "-O", target]

        else:
            print("Invalid choice")
            return ""

        print("\nScanning... please wait\n")

        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60
        )

        return result.stdout

    except subprocess.TimeoutExpired:
        print("Scan timed out")
        return ""

    except Exception as e:
        print("Error:", e)
        return ""


# FUNCTION: display_results
# simply prints the scan output in a readable format

def display_results(output):

    print("\n=== Scan Results ===")
    print("=" * 50)
    print(output)
    print("=" * 50)


# FUNCTION: save_to_file
# saves the full scan output into a text file

def save_to_file(output):

    filename = "nmap_results.txt"

    with open(filename, "w") as file:
        file.write(output)

    print(f"[+] Results saved to {filename}")


# FUNCTION: save_to_csv
# BONUS: extracts open ports from output and stores in CSV

def save_to_csv(output):

    filename = "nmap_results.csv"

    lines = output.split("\n")

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        # writing header row
        writer.writerow(["Port", "State", "Service"])

        for line in lines:
            if "/tcp" in line:
                parts = line.split()

                # making sure line has enough data
                if len(parts) >= 3:
                    writer.writerow([parts[0], parts[1], parts[2]])

    print(f"[+] CSV saved as {filename}")


# FUNCTION: log_results
# BONUS: stores scan output with timestamp in log file

def log_results(output):

    with open("nmap_log.txt", "a") as log:
        log.write("\n--- Scan at " + str(datetime.now()) + " ---\n")
        log.write(output + "\n")


# MAIN PROGRAM

if __name__ == "__main__":

    print("=== Nmap Scanner ===")

    try:
        # first checking if nmap is installed
        if not check_nmap_installed():
            print("Nmap is not installed. Please install it first.")
            sys.exit()

        print("Nmap is installed\n")

        # getting target from user (can be IP or network range)
        target = input("Enter target IP or network: ")

        print("\nSelect scan type:")
        print("1. Host Discovery (-sn)")
        print("2. Port Scan (default)")
        print("3. Custom Port Scan")
        print("4. Service Version Detection (-sV)")
        print("5. OS Detection (-O)")

        choice = input("Enter choice (1-5): ")

        # running selected scan
        output = run_nmap_scan(target, choice)

        if output != "":
            display_results(output)

            # asking user if they want to save output
            save_choice = input("\nSave results to file? (y/n): ").lower()
            if save_choice == "y":
                save_to_file(output)

            # BONUS: CSV export option
            csv_choice = input("Save results to CSV? (y/n): ").lower()
            if csv_choice == "y":
                save_to_csv(output)

            # BONUS: logging results
            log_results(output)

    except KeyboardInterrupt:
        print("\nScan interrupted by user")

    except Exception as e:
        print("Error:", e)