# ==========================================
# File Name : arp_scanner.py
# Author    : Ashwin M V
# Description : This program reads the system ARP table
#               and extracts IP and MAC address mappings.
#               It can also save results to file, CSV and log.
# ==========================================

import subprocess
import platform
import re
import csv
from datetime import datetime


# FUNCTION: get_arp_command
# this function simply returns the ARP command to run
# (kept separate in case OS-specific changes are needed later)

def get_arp_command():
    os_type = platform.system().lower()

    # currently arp -a works for both windows and linux/mac
    return ["arp", "-a"]


# FUNCTION: get_arp_table
# this function runs the arp command and collects its output

def get_arp_table():
    try:
        result = subprocess.run(
            get_arp_command(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10
        )

        return result.stdout

    except subprocess.TimeoutExpired:
        print("ARP command timed out")
        return ""

    except Exception as e:
        print("Error:", e)
        return ""


# FUNCTION: parse_arp_output
# this function uses regex to extract IP and MAC address pairs

def parse_arp_output(output):

    # regex pattern to capture IP and MAC
    pattern = r"(\d+\.\d+\.\d+\.\d+).*?([0-9a-fA-F:-]{17})"

    matches = re.findall(pattern, output)

    return matches


# FUNCTION: display_results
# displays the parsed entries in a simple table format

def display_results(entries):

    print("\n=== ARP Scanner ===")
    print("{:<20} {:<20}".format("IP Address", "MAC Address"))
    print("-" * 40)

    for ip, mac in entries:
        print("{:<20} {:<20}".format(ip, mac))

    print("\nTotal entries:", len(entries))


# FUNCTION: save_to_file
# saves the results into a normal text file

def save_to_file(entries):

    filename = "arp_results.txt"

    with open(filename, "w") as file:
        file.write("IP Address\tMAC Address\n")

        for ip, mac in entries:
            file.write(f"{ip}\t{mac}\n")

    print(f"[+] Results saved to {filename}")


# FUNCTION: save_to_csv
# BONUS: stores results in CSV format for easy viewing

def save_to_csv(entries):

    filename = "arp_results.csv"

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        # writing header
        writer.writerow(["IP Address", "MAC Address"])

        for row in entries:
            writer.writerow(row)

    print(f"[+] CSV file saved as {filename}")


# FUNCTION: log_results
# BONUS: appends scan results into a log file with timestamp

def log_results(entries):

    with open("arp_log.txt", "a") as log:
        log.write("\n--- Scan at " + str(datetime.now()) + " ---\n")

        for ip, mac in entries:
            log.write(f"{ip} | {mac}\n")


# MAIN PROGRAM

if __name__ == "__main__":

    try:
        print("Scanning ARP table...")

        output = get_arp_table()

        if output == "":
            print("No data received")
        else:
            entries = parse_arp_output(output)

            if len(entries) == 0:
                print("No ARP entries found")
            else:
                display_results(entries)

                # asking user if they want to save to text file
                choice = input("\nSave results to file? (y/n): ").lower()
                if choice == "y":
                    save_to_file(entries)

                # BONUS: CSV export option
                csv_choice = input("Save results to CSV? (y/n): ").lower()
                if csv_choice == "y":
                    save_to_csv(entries)

                # BONUS: logging results automatically
                log_results(entries)

    except KeyboardInterrupt:
        print("\nScan interrupted by user")

    except Exception as e:
        print("Error:", e)