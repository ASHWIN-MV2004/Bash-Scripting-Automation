# ==========================================
# File Name : security_audit.py
# Author    : Ashwin M V
# Description : Simple security audit tool
#               that scans ports and generates HTML report
# ==========================================

import socket
from datetime import datetime


# simple service mapping
services = {
    21: "FTP",
    22: "SSH",
    80: "HTTP",
    443: "HTTPS"
}

# simple vulnerability database
vulnerabilities = {
    "FTP": "Anonymous login vulnerability possible",
    "SSH": "Check for weak passwords",
    "HTTP": "Possible XSS or outdated server",
    "HTTPS": "Check SSL/TLS configuration"
}


# FUNCTION: scan_port
def scan_port(ip, port):

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)

    result = sock.connect_ex((ip, port))
    sock.close()

    return result == 0


# FUNCTION: generate_report
def generate_report(ip, results):

    filename = "sample_report.html"

    with open(filename, "w") as file:

        file.write("<html><body>")
        file.write(f"<h2>Security Audit Report</h2>")
        file.write(f"<p>Target: {ip}</p>")
        file.write(f"<p>Date: {datetime.now()}</p>")

        file.write("<table border='1'>")
        file.write("<tr><th>Port</th><th>Status</th><th>Service</th><th>Vulnerability</th></tr>")

        for port, status in results.items():

            service = services.get(port, "Unknown")

            if status == "OPEN":
                vuln = vulnerabilities.get(service, "No known issue")
            else:
                vuln = "-"

            file.write(f"<tr><td>{port}</td><td>{status}</td><td>{service}</td><td>{vuln}</td></tr>")

        file.write("</table>")
        file.write("</body></html>")

    print(f"\nReport generated: {filename}")


# MAIN PROGRAM

if __name__ == "__main__":

    print("=== Security Audit Tool ===")

    target = input("Enter target IP: ")

    ports = [21, 22, 80, 443]

    results = {}

    print("\nScanning...\n")

    for port in ports:

        if scan_port(target, port):
            print(f"Port {port}: OPEN")
            results[port] = "OPEN"
        else:
            print(f"Port {port}: CLOSED")
            results[port] = "CLOSED"

    generate_report(target, results)