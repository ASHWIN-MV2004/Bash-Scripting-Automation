#!/bin/bash

# q4_backup.sh
# Author : Ashwin M V

# This script creates backup of a directory using tar and timestamp.

echo "===================================="
echo "      AUTOMATED BACKUP SCRIPT      "
echo "===================================="

# ask user for source directory
read -p "Enter directory to backup: " source_dir

# check if source directory exists
if [ ! -d "$source_dir" ]; then
    echo "Error: Source directory does not exist."
    exit 1
fi

# ask user for backup destination
read -p "Enter backup destination: " backup_dest

# create destination directory if not exists
mkdir -p "$backup_dest"

# ask user for backup type
echo ""
echo "Backup Type:"
echo "1. Simple copy"
echo "2. Compressed archive (tar.gz)"

read -p "Enter choice: " backup_choice

# create timestamp using date command
time_stamp=$(date +%Y%m%d_%H%M%S)

# record start time
START=$(date +%s)

echo ""
echo "[*] Starting backup..."
echo "[*] Source      : $source_dir"
echo "[*] Destination : $backup_dest"

# perform backup based on user choice
if [ "$backup_choice" = "1" ]; then

    backup_name="backup_$time_stamp"

    echo "[*] Creating simple copy..."

    cp -r "$source_dir" "$backup_dest/$backup_name"

elif [ "$backup_choice" = "2" ]; then

    backup_name="backup_$time_stamp.tar.gz"

    echo "[*] Creating compressed archive..."

    tar -czf "$backup_dest/$backup_name" "$source_dir"

else
    echo "Invalid choice."
    exit 1
fi

# record end time
END=$(date +%s)

# calculate time taken
DURATION=$((END - START))

# verify backup was successful
if [ -e "$backup_dest/$backup_name" ]; then

    backup_size=$(du -sh "$backup_dest/$backup_name" | cut -f1)

    echo ""
    echo "Backup completed successfully!"
    echo ""
    echo "Backup Details:"
    echo "File     : $backup_name"
    echo "Location : $backup_dest"
    echo "Size     : $backup_size"
    echo "Time     : $DURATION seconds"

    echo ""
    # BONUS: create backup log file
    log_file="$backup_dest/backup_log.txt"

    echo "$(date): Backup created -> $backup_name Size: $backup_size Time: $DURATION sec" >> "$log_file"

    echo "[*] Backup logged in $log_file"

    # BONUS: email notification

    # check if mail command exists, if not install mailutils
    if ! command -v mail >/dev/null 2>&1; then
        echo "[*] Mail utility not found."
        echo "[*] Installing mailutils..."

        # install mailutils using apt
        sudo apt update >/dev/null 2>&1
        sudo apt install -y mailutils >/dev/null 2>&1

        echo "[*] Mailutils installed successfully."
    fi

    # ask user for email address
    read -p "Enter email to notify (or press Enter to skip): " email

    # send email if entered
    if [ ! -z "$email" ]; then
    {
        echo "Backup completed successfully."
        echo "File: $backup_name"
        echo "Size: $backup_size"
        echo "Time: $DURATION seconds"
    } | mail -s "Backup Successful" "$email"

    echo "[*] Email notification sent to $email"

fi

else

    echo "Backup failed."
    exit 1

fi

# BONUS: backup rotation (keep last 5 backups)
echo ""
echo "[*] Performing backup rotation..."

ls -t "$backup_dest"/backup_* 2>/dev/null | tail -n +6 | xargs rm -rf 2>/dev/null

echo "[*] Old backups deleted. Only last 5 backups kept."

echo "===================================="