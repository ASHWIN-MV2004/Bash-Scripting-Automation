========================================
CYBERSECURITY ASSIGNMENT
========================================

Name       : Ashwin M V
Assignment : Foundations of Ethical Hacking Comprehensive Assignment
Date       : April 13th, 2026

========================================
OVERVIEW
========================================

This assignment covers multiple cybersecurity concepts including:
- Linux & Bash scripting
- Python security tools
- Networking basics
- C programming
- Nmap and NSE scripting
- XSS and JavaScript
- Bonus: Security audit tool

========================================
HOW TO RUN FILES
========================================

Section 1:
chmod +x port_report.sh
./port_report.sh <IP>

Section 2:
python3 password_checker.py
python3 network_scanner.py

Section 4:
gcc pointer_basics.c -o pointer
./pointer

gcc buffer_test.c -o buffer
./buffer

gcc c_port_scanner.c -o scanner
./scanner

Section 5:
nmap -sn scanme.nmap.org
nmap --script=./http-server-info.nse scanme.nmap.org

Section 6:
Open keylogger.html in browser

Section 7:
python3 security_audit.py

========================================
TEST CASES
========================================

- Network scanner tested on scanme.nmap.org
- Buffer overflow tested with long input
- XSS tested on Juice Shop
- Nmap tested using official scanme server

========================================
BONUS IMPLEMENTED
========================================

- Security audit tool (Section 7)
- HTML report generation
- Port-service mapping
- Vulnerability detection

========================================
