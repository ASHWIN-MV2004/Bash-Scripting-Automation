#!/bin/bash

# q2_file_manager.sh
# Author : Ashwin M V

# This script provides a simple menu to manage files and directories.
# I used while loop so the menu repeats until the user chooses exit.

while true
do
    echo ""
    echo "========= FILE MANAGER ========="
    echo "1. Show files in current folder"
    echo "2. Create new directory"
    echo "3. Create new file"
    echo "4. Delete a file"
    echo "5. Rename a file"
    echo "6. Search for a file"
    echo "7. Count files and directories"
    echo "8. Show file permissions (bonus)"
    echo "9. Copy a file (bonus)"
    echo "10. Exit"
    echo "================================"

    # take user choice
    read -p "Enter your option: " option

    case $option in

    1)
        # show files with size and permissions
        ls -lh
        ;;

    2)
        # create directory
        read -p "Enter directory name: " newdir

        if [ -d "$newdir" ]; then
            echo "Directory already exists."
        else
            mkdir "$newdir"
            echo "Directory created successfully."
        fi
        ;;

    3)
        # create file
        read -p "Enter file name: " newfile

        if [ -f "$newfile" ]; then
            echo "File already exists."
        else
            touch "$newfile"
            echo "File created successfully."
        fi
        ;;

    4)
        # delete file with confirmation
        read -p "Enter file name to delete: " delfile

        if [ -f "$delfile" ]; then

            read -p "Confirm delete (y/n): " confirm

            if [ "$confirm" = "y" ]; then
                rm "$delfile"
                echo "File deleted."
            else
                echo "Delete cancelled."
            fi

        else
            echo "File not found."
        fi
        ;;

    5)
        # rename file using mv
        read -p "Enter current file name: " oldname
        read -p "Enter new file name: " newname

        if [ -f "$oldname" ]; then
            mv "$oldname" "$newname"
            echo "File renamed successfully."
        else
            echo "File not found."
        fi
        ;;

    6)
        # search file using find command
        read -p "Enter file name to search: " searchname
        find . -name "$searchname"
        ;;

    7)
        # count files and directories separately
        total_files=$(find . -type f | wc -l)
        total_dirs=$(find . -type d | wc -l)

        echo "Number of files      : $total_files"
        echo "Number of directories: $total_dirs"
        ;;

    8)
        # BONUS: show file permissions
        read -p "Enter file name: " permfile

        if [ -e "$permfile" ]; then
            ls -l "$permfile"
        else
            echo "File not found."
        fi
        ;;

    9)
        # BONUS: copy file
        read -p "Enter source file: " sourcefile
        read -p "Enter destination path: " destpath

        if [ -f "$sourcefile" ]; then
            cp "$sourcefile" "$destpath"
            echo "File copied successfully."
        else
            echo "Source file not found."
        fi
        ;;

    10)
        echo "Exiting file manager..."
        break
        ;;

    *)
        echo "Invalid option. Please try again."
        ;;

    esac

done