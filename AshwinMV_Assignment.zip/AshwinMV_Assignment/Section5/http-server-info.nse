-- ==========================================
-- File Name : http-server-info.nse
-- Author    : Ashwin M V
-- Description : This script fetches HTTP info
--               like server header, status code
--               and page title
-- ==========================================

description = [[
Retrieves HTTP server information including:
- Server header
- Status code
- Page title
]]

author = "Ashwin M V"
license = "Same as Nmap"
categories = {"safe", "discovery"}

-- load required libraries
local http = require "http"
local shortport = require "shortport"

-- run on HTTP ports
portrule = shortport.port_or_service({80, 8080}, "http")

-- main function
action = function(host, port)

    -- send HTTP GET request
    local response = http.get(host, port, "/")

    if not response then
        return "No response received"
    end

    local result = ""

    -- extract status code
    if response.status then
        result = result .. "Status Code: " .. response.status .. "\n"
    end

    -- extract server header
    if response.header and response.header["server"] then
        result = result .. "Server: " .. response.header["server"] .. "\n"
    end

    -- extract page title
    if response.body then
        local title = response.body:match("<title>(.-)</title>")
        if title then
            result = result .. "Page Title: " .. title .. "\n"
        end
    end

    return result
end
