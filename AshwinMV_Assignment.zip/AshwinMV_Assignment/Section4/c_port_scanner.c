// ==========================================
// File Name : c_port_scanner.c
// Author    : Ashwin M V
// Description : Simple port scanner using sockets
// ==========================================

#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>


// FUNCTION: scan_port
// checks whether a given port is open or closed

void scan_port(char *ip, int port) {

    int sock;
    struct sockaddr_in target;

    // create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);

    if (sock < 0) {
        printf("Socket creation failed\n");
        return;
    }

    // set target details
    target.sin_family = AF_INET;
    target.sin_port = htons(port);
    target.sin_addr.s_addr = inet_addr(ip);

    // try connecting
    int result = connect(sock, (struct sockaddr *)&target, sizeof(target));

    if (result == 0) {
        printf("Port %d: OPEN\n", port);
    } else {
        printf("Port %d: CLOSED\n", port);
    }

    close(sock);
}


// MAIN FUNCTION

int main() {

    char target_ip[] = "127.0.0.1";

    int ports[] = {22, 80, 443, 3306};

    int size = sizeof(ports) / sizeof(ports[0]);

    printf("=== C Port Scanner ===\n");
    printf("Target: %s\n\n", target_ip);

    // loop through ports
    for (int i = 0; i < size; i++) {
        scan_port(target_ip, ports[i]);
    }

    return 0;
}