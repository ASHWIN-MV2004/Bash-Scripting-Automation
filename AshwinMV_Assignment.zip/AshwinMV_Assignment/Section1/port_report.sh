#!/bin/bash

# ==========================================
# File Name : port_report.sh
# Author    : Ashwin M V
# Description : This script scans common ports
#               on a given target IP and saves
#               results to a file with summary
# ==========================================


# checking if user provided target IP
if [ $# -eq 0 ]; then
    echo "Usage: $0 <target_ip>"
    exit 1
fi

# storing target IP
TARGET=$1

# ports to scan
PORTS=(21 22 80 443 3306)

# getting current date
DATE=$(date +"%Y%m%d_%H%M%S")

# output file name
OUTPUT_FILE="scan_${TARGET}_${DATE}.txt"

# counter for open ports
OPEN_COUNT=0

echo "===================================="
echo " Port Scan Report"
echo " Target : $TARGET"
echo " Date   : $DATE"
echo "===================================="

# writing header to file
echo "Port Scan Report for $TARGET" > $OUTPUT_FILE
echo "Date: $DATE" >> $OUTPUT_FILE
echo "------------------------------------" >> $OUTPUT_FILE

# loop through ports
for PORT in "${PORTS[@]}"
do
    # using timeout to avoid hanging
    timeout 1 bash -c "echo > /dev/tcp/$TARGET/$PORT" 2>/dev/null

    # check if port is open
    if [ $? -eq 0 ]; then
        echo "Port $PORT : OPEN"
        echo "Port $PORT : OPEN" >> $OUTPUT_FILE
        OPEN_COUNT=$((OPEN_COUNT+1))
    else
        echo "Port $PORT : CLOSED"
        echo "Port $PORT : CLOSED" >> $OUTPUT_FILE
    fi
done

# writing summary
echo "------------------------------------" >> $OUTPUT_FILE
echo "Total Open Ports: $OPEN_COUNT" >> $OUTPUT_FILE

echo ""
echo "Scan completed."
echo "Total Open Ports: $OPEN_COUNT"
echo "Results saved in: $OUTPUT_FILE"
echo "===================================="
echo ""