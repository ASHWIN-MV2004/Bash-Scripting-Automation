# ==========================================
# File Name : network_scanner.py
# Author    : Ashwin M V
# Description : Scans a range of IP addresses
#               and checks ports using threading
# ==========================================

import socket
import threading


# global lock for thread safety
lock = threading.Lock()


# FUNCTION: scan_port
# checks if port is open or closed

def scan_port(ip, port, results):

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)

        result = sock.connect_ex((ip, port))

        if result == 0:
            output = f"{ip} : Port {port} OPEN"
        else:
            output = f"{ip} : Port {port} CLOSED"

        # use lock to avoid race condition
        with lock:
            print(output)
            results.append(output)

        sock.close()

    except Exception:
        pass


# FUNCTION: scan_host
# scans all ports for a single IP

def scan_host(ip, ports, results):

    for port in ports:
        scan_port(ip, port, results)


# FUNCTION: generate_ip_range
# creates list of IPs

def generate_ip_range(base_ip, start, end):

    ip_list = []

    for i in range(start, end + 1):
        ip_list.append(f"{base_ip}.{i}")

    return ip_list


# MAIN PROGRAM

if __name__ == "__main__":

    print("=== Python Network Scanner ===")

    try:
        base_ip = input("Enter base IP (e.g., 192.168.1): ").strip()

        start = int(input("Enter start range: "))
        end = int(input("Enter end range: "))

        ports = [22, 80, 443]

        results = []

        ip_list = generate_ip_range(base_ip, start, end)

        print("\nScanning... please wait\n")

        threads = []

        for ip in ip_list:
            t = threading.Thread(target=scan_host, args=(ip, ports, results))
            threads.append(t)
            t.start()

        # wait for all threads
        for t in threads:
            t.join()

        # if nothing found (rare case)
        if len(results) == 0:
            results.append("No active results found.")

        # write to file
        with open("scan_results.txt", "w") as file:
            for line in results:
                file.write(line + "\n")

        print("\nScan completed.")
        print("Results saved to scan_results.txt")

    except ValueError:
        print("Invalid input. Please enter numbers correctly.")

    except KeyboardInterrupt:
        print("\nScan interrupted by user")